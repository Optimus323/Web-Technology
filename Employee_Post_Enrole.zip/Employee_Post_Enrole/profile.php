
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Post Enrole Application</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/index.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body>
	<!--  Profile Form -->
	<div class="container-fluid bg">
		<div class="row text-center" >
			<img src="Lib/img/logo.png" alt="" class="img">
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
		<div class="col-md-10 col-sm-10 col-xs-12">
			<form action="profileinsert.php" method="post" id="ProfileFormValidate" class="form-container">
				<h1 class="text-center"><?php session_start(); echo $_POST['post']; ?> Profile Form</h1>
				<?php
				$_SESSION['post']=$_POST['post'];
				$post=$_POST['post'];
				include 'dbconnect.php';
				try {
					$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
				//$profilecount
					$stmt=$con->prepare("select Post from profile where Post=:post");
					$stmt->bindParam(':post',$post);
					$stmt->execute();
					$profilecount=$stmt->rowCount();
				//$postcount
					$stmt1=$con->prepare("select * from post where Post_Name=:post");
					$stmt1->bindParam(':post',$post);
					$stmt1->execute();
					foreach ($stmt1->fetchAll() as $key => $value) {
						$postcount=$value['Post_No'];
					}
				//check post availability
					if($profilecount<$postcount){
						require("profilecontent.php");
					}
					else{
						echo"<div class='row'>
						<div class='col-md-6'>
						<div class='col-md-offset-1 col-md-11'>
						$post Requirement Completed</div></div>
						<div class='col-md-6'>
						<div class='col-md-offset-1 col-md-11'>
						<a href='profilepost.php'class='btn btn-info'>Back to Profile</a></div></div></div>";
					}
				}
				catch (PDOException $e) {
					echo "Insertion Failed".$e->getMessage();
				}

				?>
				<!--  Profile Form Validate-->
				<script src="Lib/Jquery/bootqy.js"></script> 
				<script src="Lib/js/bootjs.js"></script>
				<script src="Lib/js/bootstrapValidator.min.js"></script>
				<script type="text/javascript">
					jQuery(document).ready(function($) {
						$('#ProfileFormValidate').bootstrapValidator({
							fields:{
								degree:{
									validators:{
										notEmpty:{
											message:'Please Enter Name'
										}
									}
								},
								domain:{
									validators:{
										notEmpty:{
											message:'Please Enter Name'
										}

									}
								},
								marks:{
									validators:{
										numeric:{
											message:"Please enter number only"
										},
										notEmpty:{
											message:"Please enter date "
										}
									}
								},
								skillset:{
									validators:{
										stringLength:{
											min:4,
											max:400,
											message:"Please Enter Letter Between 50 to 400"
										},
										notEmpty:{
											message:"Please Ennter Address"
										}
									}
								},
								post:{
									validators:{
										stringLength:{
											min:50,
											max:1000,
											message:"Please Enter Letter Between 50 to 1000"
										},
										notEmpty:{
											message:"Please Ennter Address"
										}
									}
								},
								image: {
									validators: {
										notEmpty: {
											message: 'Please select an image'
										},
										file: {
											extension: 'jpeg,jpg,png',
											type: 'image/jpeg,image/png',
                        					maxSize: 2097152,   // 2048 * 1024
                        					message: 'The selected file is not valid'
                        				}
                        			}
                        		},
                        		salary:{
                        			validators:{
                        				stringLength:{
                        					max:10,
                        					message:"Please enter atleast 4 numbers "
                        				},
                        				numeric:{
                        					message:"Please enter number only"
                        				},
                        				notEmpty:{
                        					message:"Please enter Mobile_No"
                        				}
                        			}
                        		},
                        		experience:{
                        			validators:{
                        				numeric:{
                        					message:"Please enter number only"
                        				},
                        				notEmpty:{
                        					message:"Please enter Year of Experience "
                        				}
                        			}
                        		}
                        	}
                        });

					});
				</script>
			</body>
			</html>
