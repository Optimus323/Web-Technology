-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2017 at 10:19 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `robot`
--

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
`ID` int(11) NOT NULL,
  `Post_Name` varchar(50) NOT NULL,
  `Post_No` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`ID`, `Post_Name`, `Post_No`) VALUES
(1, 'Manager', 5),
(2, 'Leader', 10),
(3, 'Developer', 15);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`ID` int(11) NOT NULL,
  `Post` varchar(50) NOT NULL,
  `Degree` varchar(50) NOT NULL,
  `Domain` varchar(100) NOT NULL,
  `Mark` double NOT NULL,
  `Skill` varchar(300) NOT NULL,
  `About_Post` varchar(1000) NOT NULL,
  `Photo` blob NOT NULL,
  `Salary` double NOT NULL,
  `Experience` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `Post`, `Degree`, `Domain`, `Mark`, `Skill`, `About_Post`, `Photo`, `Salary`, `Experience`) VALUES
(1, 'Manager', 'B.Tech', 'IT', 89, 'HTML5,CSS3,Javascript,JQuery,Bootstrap3,PHP5,Java,Python', 'I am much more like that post .Because ,this post requirement same as my skill set.', 0x5341524156414e414b554d41525f313432313136352e6a7067, 40000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
`ID` int(11) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(300) NOT NULL,
  `EmailID` varchar(100) NOT NULL,
  `PhoneNo` decimal(10,0) NOT NULL,
  `MobileNo` decimal(10,0) NOT NULL,
  `AMobileNo` decimal(10,0) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`ID`, `Firstname`, `Lastname`, `DOB`, `Address`, `EmailID`, `PhoneNo`, `MobileNo`, `AMobileNo`) VALUES
(1, 'Saravanakumar', 'S', '1997-07-15', '96c,Annamalaiyan kudieruppu,\r\nAzhiyanilai,\r\nAranathangi,\r\nPudukkottai-614616.', 'saravanakumar323it@gmail.com', '232212', '9942109912', '3231211323');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `post`
--
ALTER TABLE `post`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
 ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
