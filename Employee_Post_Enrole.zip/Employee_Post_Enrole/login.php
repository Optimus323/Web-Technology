<?php
$Username=$_POST['username'];
$Password=$_POST['password'];
include 'dbconnect.php';
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("select * from register where EmailID=:username and DOB=:password");
	$stmt->bindParam(':username',$Username);
	$stmt->bindParam(':password',$Password);
	$stmt->execute();
	$count=$stmt->rowCount();
	if($count){
		echo "<script>
		alert('Login Successful');
		window.location.href='profilepost.php';
		</script>";
	}
	else{
		echo "<script>
		alert('Login not Successful');
		window.location.href='index.php';
		</script>";
	}

} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>


