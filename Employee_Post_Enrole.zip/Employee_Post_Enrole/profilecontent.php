<div class="row">
	<div class="col-md-6">
		<div class="col-md-offset-1 col-md-11">
			<div class="form-group"><label for="">Degree</label><input type="text" class="form-control" id="degree" name="degree" placeholder="Enter Degree"></div>
			<div class="form-group"><label for="">Enter the Domain</label><input type="text" class="form-control" id="domain" name="domain" placeholder="Enter Domain"></div>
			<div class="form-group"><label for="">Percentage of Marks</label><input type="text" class="form-control" id="marks" name="marks" placeholder="Enter Marks"></div>
			<div class="form-group"><label for="">Skill Set</label><input type="text" class="form-control" id="skillset" name="skillset" placeholder="Enter Skill Set"></div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="col-md-offset-1 col-md-11">
			<div class="form-group"><label for="">What do you know about the post that you are apply</label><textarea name="post"  cols="100" rows="5" id="post" class="form-control" placeholder="Tell About the Post ..."></textarea></div>
			<div class="form-group"><label for="">Photo</label><input type="file" id="photo" name="image" ></div>
			<div class="form-group"><label for="">Salary Expected (Rs) </label><input type="text" class="form-control" id="salary" name="salary" placeholder="Enter Salary" ></div>
			<div class="form-group"><label for="">Experience</label><input type="text" class="form-control" id="experience" name="experience" placeholder="Enter Year of Experience " ></div>
		</div>
	</div>
</div>
<div class="row text-center"><input type="submit" class="btn btn-success" value="Submit"></div> 
</form>
</div>
<div class="col-md-1 col-sm-1 col-xs-12">
	<div><h1 id="test"></h1></div>
</div>
</div>
