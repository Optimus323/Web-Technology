<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Post Enrole Application</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.css">
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/index.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body>
	<!--  ProfilePost Form -->
	<div class="container-fluid bg">
		<div class="row text-center" >
			<img src="Lib/img/logo.png" alt="" class="img">
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
		<div class="col-md-10 col-sm-10 col-xs-12">
			<form action="profile.php" method="post" id="ProfilePostFormValidate" class="form-container">
				<h1 class="text-center">Profile Form</h1>
				<div class="row ">
					<div class="form-group col-md-offset-4 col-md-4"><label for="">Post</label>
						<select name="post" id="position" name="post" class="form-control">
							<option value="">Select Your Post</option>
							<option value="Manager" id="black">Manager</option>
							<option value="Leader" id="black">Leader</option>
							<option value="Developer" id="black">Developer</option>
						</select>		
					</div>
				</div>
				<div class="row text-center"><input type="submit" class="btn btn-success" value="Submit"></div> 
			</form>
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12">
			<div><h1 id="test"></h1></div>
		</div>
	</div>
	<!--  ProfilePost Form Validate-->
	<script src="Lib/Jquery/bootqy.js"></script> 
	<script src="Lib/js/bootjs.js"></script>
	<script src="Lib/js/bootstrapValidator.min.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('#ProfilePostFormValidate').bootstrapValidator({
				fields:{
					post:{
						validators:{
							notEmpty:{
								message:"Please select your role"
							}
						}
					}
				}
			});

		});
	</script>
</body>
</html>