<?php
session_start();
$postname=$_SESSION['post'];
$Degree=$_POST['degree'];
$Domain=$_POST['domain'];
$Mark=$_POST['marks'];
$Skill=$_POST['skillset'];
$Post=$_POST['post'];
$TmpFile=$_POST['image'];
$Salary=$_POST['salary'];
$Experience=$_POST['experience'];
include 'dbconnect.php';
try{
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("insert into profile (Post,Degree,Domain,Mark,Skill,About_Post,Photo,Salary,Experience)values(:postname,:degree,:domain,:mark,:skillset,:post,:image,:salary,:experience)");
	$stmt->bindParam(':postname',$postname);
	$stmt->bindParam(':degree',$Degree);
	$stmt->bindParam(':domain',$Domain);
	$stmt->bindParam(':mark',$Mark);
	$stmt->bindParam(':skillset',$Skill);
	$stmt->bindParam(':post',$Post);
	$stmt->bindParam(':image',$TmpFile);
	$stmt->bindParam(':salary',$Salary);
	$stmt->bindParam(':experience',$Experience);
	$stmt->execute();
	 echo"<script>
	alert('Profile Data Insertion Successfully');
	window.location.href='index.php';
	</script>";

   #                     Send Mail








	//header("Location:index.php");
} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>