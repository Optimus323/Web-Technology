<?php
$Firstname=$_POST['firstname'];
$Lastname=$_POST['lastname'];
$Dob=$_POST['dob'];
$Address=$_POST['address'];
$Email=$_POST['email'];
$Phoneno=$_POST['phoneno'];
$Mobileno=$_POST['mobileno'];
$AlterMobileno=$_POST['altermobileno'];
include 'dbconnect.php';
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("insert into register (Firstname,Lastname,DOB,Address,EmailID,PhoneNo,MobileNo,AMobileNo)values(:firstname,:lastname,:dob,:address,:email,:phoneno,:mobileno,:altermobileno)");
	$stmt->bindParam(':firstname',$Firstname);
	$stmt->bindParam(':lastname',$Lastname);
	$stmt->bindParam(':dob',$Dob);
	$stmt->bindParam(':address',$Address);
	$stmt->bindParam(':email',$Email);
	$stmt->bindParam(':phoneno',$Phoneno);
	$stmt->bindParam(':mobileno',$Mobileno);
	$stmt->bindParam(':altermobileno',$AlterMobileno);
	$stmt->execute();
	echo"<script>
	alert('Register Data Insertion Successfully');
	window.location.href='index.php';
	</script>";
} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>
</body>
</html>
