<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
<?php
	$email=$_POST['email'];
	include 'dbconnect.php';
	try {
		$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
		$stmt=$con->prepare("select * from register where EmailID=:email");
		$stmt->bindParam(':email',$email);
		$stmt->execute();
		$count=$stmt->rowCount();
		foreach ($stmt->fetchAll() as $key => $value) {
	if($count){
		echo "<script>
				alert('Your Password is ".$value['DOB']."');
				window.location.href='index.php';
				</script>";
	}
	else{
	echo "<script>
				alert('Please enter valid Email ID ');
				window.location.href='index.php';
				</script>";
}
}
}
	 catch (PDOException $e) {
		echo "Insertion Failed".$e->getMessage();
	}

	?>
	</body>
</html>