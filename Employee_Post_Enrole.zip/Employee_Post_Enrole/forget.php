<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Post Enrole Application</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/index.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body>
	<!--  Forget Form -->
	<div class="container-fluid bg">
		<div class="row text-center" >
			<img src="Lib/img/logo.png" alt="" class="img">
		</div>
		<div class="col-md-2 col-sm-2 col-xs-12"></div>
		<div class="col-md-8 col-sm-8 col-xs-12">\
			<form action="forgetdata.php"  class="form-container" method="post">
				<h1 class="text-center">Forget Form</h1>
				<div class="form-group"><label for="">Email ID</label><input type="text" name="email" placeholder="Enter Email_ID" class="form-control"></div>
				<div class="form-group"><input type="submit"  class="btn btn-info"></div>
			</div>
			<div class="col-md-2 col-sm-2 col-xs-12"></div>
		</div>
	</form>
</div>

</body>
</html>