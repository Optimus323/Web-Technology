<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Post Enrole Application</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/index.css">
	<link rel="stylesheet" href="Lib/datepicker/jquery.datetimepicker.min.css">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}

</style>
</head>
<body>
	<!--  register Form -->
	<div class="container-fluid bg">
		<div class="row text-center" >
			<img src="Lib/img/logo.png" alt="" class="img">
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
		<div class="col-md-10 col-sm-10 col-xs-12">
			<form action="registerinsert.php" method="post" id="ProfileFormValidate" class="form-container">
				<h1 class="text-center">Registration Form</h1>
				<div class="row">
					<div class="col-md-6">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for="">First Name</label><input type="text" class="form-control" id="fname" name="firstname" placeholder="Enter First_name"></div>
							<div class="form-group"><label for="">Last Name</label><input type="text" class="form-control" id="fname" name="lastname" placeholder="Enter Last_name"></div>
							<div class="form-group"><label for="">Date Of Birth</label><input type="text" class="form-control" id="dob" name="dob" placeholder="dd/mm/yyyy" ></div>
							<div class="form-group"><label for="">Address</label><textarea name="address"  cols="100" rows="5" id="address" class="form-control" placeholder="Enter Address..."></textarea></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for="">Email ID</label><input type="text" id="email" class="form-control" name="email" placeholder="Enter Email-ID"></div>
							<div class="form-group"><label for="">Phone No</label><input type="text" class="form-control" id="pno" name="phoneno" placeholder="Enter Phone_No" ></div>
							<div class="form-group"><label for="">Mobile No</label><input type="text" class="form-control" id="mno" name="mobileno" placeholder="Enter Mobile_No" ></div>
							<div class="form-group"><label for="">Alter Mobile No</label><input type="text" class="form-control" id="amno" name="altermobileno" placeholder="Enter Alter_Mobile_No" ></div>
						</div>
					</div>
				</div>
				<div class="row text-center"><input type="submit" class="btn btn-success" value="Register"></div> 
			</form>
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
	</div>
	<!--  register Form Validation -->
	<script src="Lib/js/bootjs.js"></script>
	<script src="Lib/Jquery/bootqy.js"></script>
	<script src="Lib/js/bootstrapValidator.min.js"></script>
	<script src="Lib/datepicker/jquery.datetimepicker.full.min.js"></script>
	<script type="text/javascript">
		$( function() {
			$( "#dob" ).datetimepicker();
		} );
		jQuery(document).ready(function($) {
			$('#ProfileFormValidate').bootstrapValidator({
				fields:{
					firstname:{
						validators:{
							regexp:{
								regexp: /^[a-z\s]+$/i,
								message:"Please enter name using letter and space"
							},
							notEmpty:{
								message:'Please Enter Name'
							}
						}
					},
					lastname:{
						validators:{
							regexp:{
								regexp: /^[a-z\s]+$/i,
								message:"Please enter name using letter and space"
							},
							notEmpty:{
								message:'Please Enter Name'
							}

						}
					},
					dob:{
						validators:{
							date:{
								format:"YYYY/MM/DD",
								message:"Please enter correct date format"
							},
							notEmpty:{
								message:"Please enter date "
							}
						}
					},
					address:{
						validators:{
							stringLength:{
								min:5,
								max:400,
								message:"Please Enter Letter Between 50 to 400"
							},
							notEmpty:{
								message:"Please Ennter Address"
							}
						}
					},
					email:{
						validators:{
							emailAddress:{
								message:"Please enter valid Email address"
							},
							notEmpty:{
								message:"Please enter Email-ID"
							}
						}
					},
					phoneno:{
						validators:{
							stringLength:{
								min:6,
								max:6,
								message:"Please enter 6 numbers only"
							},
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Phone_No"
							}
						}
					},
					mobileno:{
						validators:{
							stringLength:{
								min:10,
								max:10,
								message:"Please enter 10 numbers only"
							},
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Mobile_No"
							}
						}
					},
					altermobileno:{
						validators:{
							stringLength:{
								min:10,
								max:10,
								message:"Please enter 10 numbers only"
							},
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Alter_Mobile_No"
							}
						}
					}
				}
			});
		});
	</script>
</body>
</html>