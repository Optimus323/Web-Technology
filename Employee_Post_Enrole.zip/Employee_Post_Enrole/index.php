<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Post Enrole Application</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/index.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body class=" animated fadeIn">
	<!--  Login Form -->
	<div class="container-fluid bg">
		<div class="row text-center" >
			<img src="Lib/img/logo.png" alt="" class="img">
		</div>
		<div class="row text-center">
			<div class="col-md-4 col-sm-4 col-xs-12 col-sm-offset-4 col-md-offset-4">
				<form action="login.php" id="loginvalidate" method="post" class="form-container animated fadeIn">
					<h1 class=" login text-center animated fadeInDown">Login Form</h1>
					<div class="form-group"><label for="" class="animated bounceInLeft label1">Username</label><input type="email" class="form-control animated bounceInLeft username" name="username" placeholder="Enter_Email"></div>
					<div class="form-group"><label for="" class="animated bounceInLeft label2">Password</label><input type="password" class="form-control animated bounceInLeft password" name="password" placeholder="Enter_Password"></div>
					<div class="form-group"><input type="submit"  value="Login" class="btn btn-success btn-block animated bounceInLeft button1"></div>
					<div class="row col-md-12">
						<div class="col-md-6 col-sm-6 col-xs-12 form-group">
							<a href="register.php"><input type="button" class="btn btn-info animated bounceInLeft button2" value="Register Here"></a></div>
							<div class="col-md-6 col-sm-6 col-xs-12 form-group"><a href="forget.php"><input type="button" class="btn btn-danger animated bounceInLeft button3" value="Forget Password"></a></div>
						</div>
					</form>
				</div>
			</div>
			<!--  Login Form Validation -->
			<script src="Lib/js/bootjs.js"></script>
			<script src="Lib/Jquery/bootqy.js"></script>
			<script src="Lib/js/bootstrapValidator.min.js"></script>
			<script>
				jQuery(document).ready(function($) {
					$('#loginvalidate').bootstrapValidator({
						fields:{
							username:{
								validators:{
									emailAddress:{
										message:"Please enter valid email address"
									},
									notEmpty:{
										message:"Please enter Email"
									}
								}
							},
							password:{
								validators:{
									notEmpty:{
										message:"Please enter password"
									}
								}
							}
						}
					});
				});
			</script>
		</body>
		</html>