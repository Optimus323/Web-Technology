<?php
$server="localhost";// your server name or IP address
$dbname="robot";//your database name
$username="root";//your database username
$password="";// your database password
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e) {
	echo "Connection Failed".$e->getMessage();
}

?>