<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>WATER CONSUMPTION BILLING SYSTEM</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/indexstyle.css
	">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body>
	<!--  Forget Form -->
	<div class="container-fluid bg">
		<div class="col-md-3 col-sm-3 col-xs-12"></div>
		<div class="col-md-6 col-sm-6 col-xs-12">
			<form action="removeuser.php" method="post" id="ProfileFormValidate" class="form-container">
				<div class="row text-center" >
						<img src="Lib/img/logo.jpg" alt="" class="img animated fadeInDown">
					</div>
					<h1 class=" login text-center animated fadeInDown">Remove User</h1>
				<div class="row">
					<div class="col-md-1">
					</div>
					<div class="col-md-10">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for="">House No</label><input type="text" class="form-control" id="hno" name="hno" placeholder="Enter House_No"></div>
						</div>
					</div>
					<div class="col-md-1">
					</div>
				</div>
				<div class="row text-center"><input type="submit" class="btn " style="background-color:#262673; color:white" value="Remove"></div> 
			</form>
		</div>
		<div class="col-md-3 col-sm-3 col-xs-12"></div>
	</div>
	<footer>&copy; Copyright 2017 OP Technologies</footer>
</body>
</html>