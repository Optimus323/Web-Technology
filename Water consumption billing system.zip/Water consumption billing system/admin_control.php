<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>WATER CONSUMPTION BILLING SYSTEM</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/indexstyle.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
	
</style>
</head>
<body class=" animated fadeIn">
	<!--  Admin_Control -->
	<div class="container-fluid bg">
		<div class="row text-center">
			<div class="control col-md-4 col-sm-4 col-xs-12 col-sm-offset-4 col-md-offset-4">
				<form  class="form-container animated fadeIn">
					<div class="row text-center" >
						<img src="Lib/img/logo.jpg" alt="" class="img animated fadeInDown">
					</div>
					<h1 class=" login text-center animated fadeInDown">Admin Control</h1>
					<div class="form-group">
						<a href="userentry.php" class="btn  btn-lg btn-block" style="background-color:#262673; color:white">User_Entry</a>
					</div>
					<div class="form-group">
						<a href="Consumption.php" class="btn btn-lg btn-block" style="background-color:#262673; color:white">Consumption</a>
					</div>
					<div class="form-group">
						<a href="Remove.php" class="btn  btn-lg btn-block" style="background-color:#262673; color:white">User_Remove</a>
					</div>
					<a href="index.php" class="btn" style="background-color:#262673; color:white">Logout</a>
				</form>
			</div>
		</div>
		<footer>&copy; Copyright 2017 OP Technologies</footer>
	</body>
	</html>