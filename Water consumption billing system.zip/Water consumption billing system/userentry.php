<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>WATER CONSUMPTION BILLING SYSTEM</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/indexstyle.css">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<link rel="stylesheet" href="Lib/datepicker/jquery.datetimepicker.min.css">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}

</style>
</head>
<body>
	<!--  User_Entry Form -->
	<div class="container-fluid bg">
		<div class="col-md-3 col-sm-3 col-xs-12"></div>
		<div class="col-md-6 col-sm-6 col-xs-12">
			<form action="insertuser.php" method="post" id="ProfileFormValidate" class="form-container">
				<div class="row text-center" >
						<img src="Lib/img/logo.jpg" alt="" class="img animated fadeInDown">
					</div>
					<h1 class=" login text-center animated fadeInDown">Admin Control</h1>
				<div class="row">
					<div class="col-md-1">
					</div>
					<div class="col-md-10">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for="">House No</label><input type="text" class="form-control" id="hno" name="hno" placeholder="Enter House_No"></div>
							<div class="form-group"><label for="">Name</label><input type="text" class="form-control" id="uname" name="username" placeholder="Enter User_name"></div>
							<div class="form-group"><label for="">Email</label><input type="text" id="email" class="form-control" name="email" placeholder="Enter Email-ID"></div>
							<div class="form-group"><label for="">Password</label><input type="text" class="form-control" id="password" name="pass" placeholder="Enter Password"></div>
						</div>
					</div>
					<div class="col-md-1">
					</div>
				</div>
				<div class="row text-center"><input type="submit" class="btn " style="background-color:#262673; color:white" value="Entry"></div> 
			</form>
		</div>
		<div class="col-md-3 col-sm-3 col-xs-12"></div>
	</div>
	<!--  register Form Validation -->
	<script src="Lib/js/bootjs.js"></script>
	<script src="Lib/Jquery/bootqy.js"></script>
	<script src="Lib/js/bootstrapValidator.min.js"></script>
	<script src="Lib/datepicker/jquery.datetimepicker.full.min.js"></script>
	<script type="text/javascript">
		$( function() {
			$( "#dob" ).datetimepicker();
		} );
		jQuery(document).ready(function($) {
			$('#ProfileFormValidate').bootstrapValidator({
				fields:{
					hno:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter House_Number"
							}
						}
					},
					username:{
						validators:{
							regexp:{
								regexp: /^[a-z\s]+$/i,
								message:"Please enter name using letter and space"
							},
							notEmpty:{
								message:'Please Enter Name'
							}

						}
					},
					email:{
						validators:{
							emailAddress:{
								message:"Please enter valid Email address"
							},
							notEmpty:{
								message:"Please enter Email-ID"
							}
						}
					},
					pass:{
						validators:{
							stringLength:{
								min:8,
								message:"Please enter greater then 8 character only"
							},
							notEmpty:{
								message:"Please enter Password"
							}
						}
					},
					status:{
						validators:{
							notEmpty:{
								message:"Please enter status"
							}
						}
					}
				}
			});
		});
	</script>
	<footer>&copy; Copyright 2017 OP Technologies</footer>
</body>
</html>