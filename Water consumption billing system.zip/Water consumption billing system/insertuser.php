<?php
$hno=$_POST['hno'];
$name=$_POST['username'];
$email=$_POST['email'];
$pass=$_POST['pass'];
include 'dbconnect.php';
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("insert into tbl_user (house_number,user_name,user_email,user_password)values(:hno,:name,:email,:pass)");
	$stmt->bindParam(':hno',$hno);
	$stmt->bindParam(':name',$name);
	$stmt->bindParam(':email',$email);
	$stmt->bindParam(':pass',$pass);
	$stmt->execute();
	echo"<script>
	alert('Register Data Insertion Successfully');
	window.location.href='admin_control.php';
	</script>";
} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>
</body>
</html>
