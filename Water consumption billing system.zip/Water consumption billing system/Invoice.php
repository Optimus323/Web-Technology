<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>WATER CONSUMPTION BILLING SYSTEM</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<link rel="stylesheet" type="text/css" href="Lib/css/indexstyle.css
	">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}
</style>
</head>
<body>
	<!--  Forget Form -->
	<div class="container-fluid bg">
		<div class="col-md-2 col-sm-2 col-xs-12"></div>
		<div class="col-md-8 col-sm-8 col-xs-12 form-container">
			<div class="row text-center" >
						<img src="Lib/img/logo.jpg" alt="" class="img animated fadeInDown">
					</div>
					<h1 class=" login text-center animated fadeInDown">Invoice</h1>
			<?php 
include 'dbconnect.php';
try {
session_start();
$hno=$_SESSION['houseno'];
	$conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$conn->prepare("select house_number,house_owner_name,initial_reading,end_reading,total_consumption,bill_amount from tbl_consumption where house_number=$hno ");
	$stmt->execute();
	$result=$stmt->setFetchMode(PDO::FETCH_ASSOC);
	echo"
<table class='table table-responsive '>
				<tbody>
	";
	foreach ($stmt->fetchAll() as $key => $value) {
		# code...
		echo"<tr>
					<td>House Number</td><td>".$value['house_number']."</td>
					</tr>
					<tr>
						<td>Owner Name</td><td>".$value['house_owner_name']."</td>
					</tr>
					<tr>
						<td>Initial Reading</td><td>".$value['initial_reading']."</td>
					</tr>
					<tr>
						<td>End Reading</td><td>".$value['end_reading']."</td>
					</tr>
					<tr>
						<td>Total Reading</td><td>".$value['total_consumption']."</td>
					</tr>
					<tr>
						<td>Consumption Charge</td><td>".$value['bill_amount']."</td>
					</tr>";
	}
	echo"</tbody>
			</table>";
} catch (PDOException $e) {
	echo 'Connection Failed'.$e->getMessage();
}
 ?>
 <a href="index.php" class="btn " style="background-color:#262673; color:white">Logout</a>
  <a class="btn " onclick="myFunction()" style="background-color:#262673; color:white">Print</a>
 <script>
function myFunction() {
    window.print();
}
</script>
</div>
</div>
<footer>&copy; Copyright 2017 OP Technologies</footer>
</body>
</html>