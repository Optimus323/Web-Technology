<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
<?php
	$hno=$_POST['hno'];
	include 'dbconnect.php';
	try {
		$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
		$stmt=$con->prepare("delete  from tbl_user where house_number=:hno");
		$stmt1=$con->prepare("delete  from tbl_consumption where house_number=:hno");
		$stmt->bindParam(':hno',$hno);
		$stmt1->bindParam(':hno',$hno);
		$stmt->execute();
		$stmt1->execute();
		$count=$stmt->rowCount();
		$count1=$stmt1->rowCount();
	if($count and $count1){
		echo "<script>
				alert('delete success ');
				window.location.href='admin_control.php';
				</script>";
	}
	else{
	echo "<script>
				alert('Not availabe this house number!');
				window.location.href='admin_control.php';
				</script>";
}
}
	 catch (PDOException $e) {
		echo "Insertion Failed".$e->getMessage();
	}

	?>
	</body>
</html>