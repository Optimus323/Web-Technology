<?php
$house_number=$_POST['hno'];
$house_owner_name=$_POST['honame'];
$initial_reading=$_POST['initread'];
$end_reading=$_POST['endread'];
$total_consumption=$_POST['totcon'];
$current_cost=$_POST['Cost'];
$bill_amount=$_POST['bamt'];
include 'dbconnect.php';
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("insert into tbl_consumption (house_number,house_owner_name,initial_reading,end_reading,total_consumption,current_cost,bill_amount)values(:house_number,:house_owner_name,:initial_reading,:end_reading,:total_consumption,:current_cost,:bill_amount)");
	$stmt->bindParam(':house_number',$house_number);
	$stmt->bindParam(':house_owner_name',$house_owner_name);
	$stmt->bindParam(':initial_reading',$initial_reading);
	$stmt->bindParam(':end_reading',$end_reading);
	$stmt->bindParam(':total_consumption',$total_consumption);
	$stmt->bindParam(':current_cost',$current_cost);
	$stmt->bindParam(':bill_amount',$bill_amount);
	$stmt->execute();
	echo"<script>
	alert('Register Data Insertion Successfully');
	window.location.href='admin_control.php';
	</script>";
} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>
</body>
</html>
