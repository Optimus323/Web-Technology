<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>WATER CONSUMPTION BILLING SYSTEM</title>
	<link rel="stylesheet" href="Lib/css/bootstrap.min.css">
	<link rel="stylesheet" href="Lib/css/indexstyle.css">
	<link rel="stylesheet" href="Lib/css/animate.css">
	<link rel="stylesheet" href="Lib/datepicker/jquery.datetimepicker.min.css">
	<style type="text/css">
	@font-face {
		font-family: myFirstFont;
		src: url(Lib/font/batmfa__.ttf);
	}

</style>
</head>
<body>
	<!--  Consumption Form -->
	<div class="container-fluid bg">
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
		<div class="col-md-10 col-sm-10 col-xs-12">
			<form action="insertconsumption.php" method="post" id="ProfileFormValidate" class="form-container">
				<div class="row text-center" >
						<img src="Lib/img/logo.jpg" alt="" class="img animated fadeInDown">
					</div>
					<h1 class=" login text-center animated fadeInDown">Consumption Details</h1>
				<div class="row">
					<div class="col-md-6">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for="">House Number</label><input type="text" class="form-control" id="hno" name="hno" placeholder="Enter House_No"></div>
							<div class="form-group"><label for="">House Owner Name</label><input type="text" class="form-control" id="honame" name="honame" placeholder="Enter House_Owner_name"></div>
							<div class="form-group"><label for="">Current Cost</label><input type="text" id="Cost" class="form-control" name="Cost"  ></div>
							<div class="form-group"><label for="">Bill Amount</label><input type="text" class="form-control" id="bamt" name="bamt"  ></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="col-md-offset-1 col-md-11">
							<div class="form-group"><label for=""><h5><b>Water Consumption Reading</b></h5></label></div>
							<div class="form-group"><label for="">Initial Reading</label><input type="text" class="form-control" id="initread" name="initread" placeholder="Enter Initial_Reading" ></div>
							<div class="form-group"><label for="">End Reading</label><input type="text" class="form-control" id="endread" name="endread" placeholder="Enter End_Reading" ></div>
							<div class="form-group"><label for="">Total Consumption </label><input type="text" class="form-control" id="totcon" name="totcon"  ></div>
						</div>
					</div>
				</div>
				<div class="row text-center"><input type="submit" class="btn" style="background-color:#262673; color:white" value="Register"></div> 
			</form>
		</div>
		<div class="col-md-1 col-sm-1 col-xs-12"></div>
	</div>
	<!--  register Form Validation -->
	<script src="Lib/js/bootjs.js"></script>
	<script src="Lib/Jquery/bootqy.js"></script>
	<script src="Lib/js/bootstrapValidator.min.js"></script>
	<script src="Lib/datepicker/jquery.datetimepicker.full.min.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
				var ir=0,er=0,tot=0,amt=0,cost=0;
			$("#initread").mouseleave(function(){
  				ir=$("#initread").val();
  				tot=parseInt(er)- parseInt(ir);
               $("#totcon").val(tot);
               amt=parseInt(cost)*parseInt(tot);
           $("#bamt").val(amt);
			});
			$("#endread").mouseleave(function(){
  				er=$("#endread").val();
  				tot=parseInt(er)- parseInt(ir);
               $("#totcon").val(tot);
               amt=parseInt(cost)*parseInt(tot);
           $("#bamt").val(amt);
			});
               
           $("#Cost").mouseleave(function(){
  				cost=$("#Cost").val();
  				amt=parseInt(cost)*parseInt(tot);
           $("#bamt").val(amt);
			});
	//document.writeln(ir+""+er+""+tot+""+amt);

			$('#ProfileFormValidate').bootstrapValidator({
				fields:{
					hno:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter House_No"
							}
						}
					},
					honame:{
						validators:{
							regexp:{
								regexp: /^[a-z\s]+$/i,
								message:"Please enter name using letter and space"
							},
							notEmpty:{
								message:'Please Enter House_Owner_Name'
							}
						}
					},
					Cost:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Current_Cost"
							}
						}
					},
					bamt:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Bill_Amt"
							}
						}
					},
					initread:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter Initial_Reading"
							}
						}
					},
					endread:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter End_Reading"
							}
						}
					},
					totcon:{
						validators:{
							numeric:{
								message:"Please enter number only"
							},
							notEmpty:{
								message:"Please enter End_Reading"
							}
						}
					}
				}
			});
		});
	</script>
	<footer>&copy; Copyright 2017 OP Technologies</footer>
</body>
</html>