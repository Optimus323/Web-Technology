<?php
$Username=$_POST['username'];
$Password=$_POST['password'];
include 'dbconnect.php';
try {
	$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
	$stmt=$con->prepare("select * from tbl_user where user_email=:username and user_password=:password");
	$stmt->bindParam(':username',$Username);
	$stmt->bindParam(':password',$Password);
	$stmt->execute();
	$result=$stmt->setFetchMode(PDO::FETCH_ASSOC);
	foreach ($stmt->fetchAll() as $key => $value) {
		foreach ($value as $key1 => $value1) {
					if(strcmp($key1,"house_number")==0){
						session_start();
					$_SESSION['houseno']=$value1;
				}
		}
	}
	$count=$stmt->rowCount();
	$stmt1=$con->prepare("select * from tbl_admin where admin_email=:username and admin_password=:password");
	$stmt1->bindParam(':username',$Username);
	$stmt1->bindParam(':password',$Password);
	$stmt1->execute();
	$count1=$stmt1->rowCount();
	if($count){
		echo "<script>
		alert('User Login Successful');
		window.location.href='Invoice.php';
		</script>";
		
	}
	else if($count1){
		echo "<script>
		alert('Admin Login Successful');
		window.location.href='admin_control.php';
		</script>";
	}
	else{
		echo "<script>
		alert('Login not Successful');
		window.location.href='index.php';
		</script>";
	}

} catch (PDOException $e) {
	echo "Insertion Failed".$e->getMessage();
}
?>


