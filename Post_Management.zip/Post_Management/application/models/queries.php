<?php
class queries extends CI_Model{
	public function getPosts(){
		$query = $this->db->get('tbl_post');
		if ($query->num_rows()>0) {
			return $query->result();
		}
	}
	public function addPost($data){
		return $this->db->insert('tbl_post', $data);
	}
	public function updatePost($id){
	$query = $this->db->get_where('tbl_post', array('id' => $id));
		if ($query->num_rows() >0) {
			return $query->row();
		}
	}
	public function addUpdatePost($id,$data){
		return $this->db->where('id',$id)
					    ->update('tbl_post', $data);
	}
	public function deletePost($id){
		return $this->db->delete('tbl_post',array('id'=>$id));
	}
}

?>
