<?php include_once('header.php'); ?>
<div class="container">
	<div class="panel panel-primary">
  <div class="panel-heading">
    <h1 class="panel-title"><?php echo $post->title; ?></h1>
  </div>
  <div class="panel-body">
    <p><?php echo $post->description; ?></p>
  </div>
  <div class="panel-footer">
  	<strong class="text-center"><?php echo $post->postdate; ?></strong>
  </div>
</div>
<?php echo anchor('Welcome', 'Back', array('class' => 'btn btn-default')); ?>
</div>
<?php include_once('footer.php'); ?>
