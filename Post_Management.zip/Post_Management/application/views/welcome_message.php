<?php include_once('header.php'); ?>
<div class="container">
	<h3>View All Post</h3>
	<?php if($msg=$this->session->flashdata('msg')): ?>
		<?php echo $msg;?>
	<?php endif; ?>
	<?php echo anchor('Welcome/create', 'Add Post', array('class' => 'btn btn-primary btn-lg')); ?>
	<table class="table table-striped table-hover ">
		<thead>
			<tr>
				<th>ID</th>
				<th>Title</th>
				<th>Description</th>
				<th>Post Date</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<?php if (count($posts)):?>
					<?php foreach ($posts as $key => $post):?>
						<td><?php echo $post->id; ?></td>
						<td><?php echo $post->title; ?></td>
						<td><?php echo $post->description; ?></td>
						<td><?php echo $post->postdate; ?></td>
						<td>

							<?php echo anchor("Welcome/view/{$post->id}", 'View', array('class' => 'btn btn-info')); ?>
							<?php echo anchor("Welcome/update/{$post->id}", 'Update', array('class' => 'btn btn-warning ')); ?>
							<?php echo anchor("Welcome/delete/{$post->id}", 'Delete', array('class' => 'btn  btn-danger ')); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr>
					<tr>No record are not found</tr>
				</tr>
			<?php endif; ?>
		</tbody>
	</table> 
</div>
<?php include_once('footer.php'); ?>
