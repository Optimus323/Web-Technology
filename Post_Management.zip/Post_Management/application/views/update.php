<?php include_once('header.php'); ?>
<div class="container">
	<?php echo form_open("Welcome/saveupdate/{$post->id}",array('class'=>'form-horizontal')); ?>
	<fieldset>
		<legend>Update Post</legend>
		<div class="form-group">
			<label for="inputEmail" class="col-md-2 control-label">Title</label>
			<div class="col-md-5">
				<?php echo form_input(array('name'=>'title','class'=>'form-control','placeholder'=>'Enter_Title','value'=>set_value('title',$post->title))); ?>
			</div>
				<div class="col-md-5">
					<?php echo form_error('title','<div class="text-danger">','</div>') ?>
			</div>
		</div>
		<div class="form-group"> 
			<label for="textArea" class="col-md-2 control-label">Description</label>
			<div class="col-md-5">
				<?php echo form_textarea(array('name'=>'description','class'=>'form-control','placeholder'=>'Enter_Description','value'=>set_value('description',$post->description))); ?>
			</div>
			<div class="col-md-5">
				<?php echo form_error('description','<div class="text-danger">','</div>') ?>
			</div>
		</div>
		<div class="form-group">
			<div class="col-md-5 col-md-offset-2">
				<?php echo form_submit(array('class' => 'btn  btn-primary','name'=>'submit','value'=>'Update')); ?>
				<?php echo anchor('Welcome', 'Back', array('class' => 'btn btn-default')); ?>
			</div>
		</div>
	</fieldset>
</form>
</div>
<?php include_once('footer.php'); ?>
