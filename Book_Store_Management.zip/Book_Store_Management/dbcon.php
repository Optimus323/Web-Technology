<?php
$server="localhost";
$dbname="store";
$username="root";
$password="";
try {
$con=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
$con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e) {
	echo "Connection Failed".$e->getMessage();
}

 ?>