<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Store Application</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	#white{
		color:white;
	}
	#white:hover{
		background-color: lightskyblue;
	}
	.container{
		margin-top: 130px;
	}
	.bg{
	background: url('Lib/img/water-lily-pink-aquatic-plant-pink-water-lily-127584.jpeg')no-repeat;
	width: 100%;
	height: 100vh;
}
.form-container,.container{
	border:1px solid  #fff;
	padding :50px 60px;
	-webkit-box-shadow: 2px 6px 43px 1px rgba(0,0,0,0.75);
-moz-box-shadow: 2px 6px 43px 1px rgba(0,0,0,0.75);
box-shadow: 2px 6px 43px 1px rgba(0,0,0,0.75);
}
</style>
</head>
<body>
							<!--  Store_Head -->

	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid bg-primary">
			<h1 class="text-center" >Book Store</h1>
			<div class="navbar-header">
				<button class="navbar-toggle" data-toggle="collapse" data-target="#Bar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div class="navbar-brand" id="white">WELCOME</div>
			</div>
			<div class="collapse navbar-collapse" id="Bar">
				<ul class="nav navbar-nav">
					<li><a href="" id="white">Home</a></li>
					<li><a href="" id="white">Service</a></li>
					<li><a href="" id="white">Login</a></li>
					<li><a href="" id="white">SignUp</a></li>
				</ul>
			</div>
		</div>
	</nav>
			<div class="container-fluid bg">				<!--  Store_Body -->
	<div class="container">
		<div class="panel panel-warning">
			<div class="panel-body bg-primary">
			<div class="row">
				<div class="col-md-6">
					<form action="insert.php" method="post" id="Validate" class='form-container'>
						<h2 class="text-center">Application</h2>
						<div class="form-group"><label for="">Book Title</label><input type="text" class="form-control" name="bookname" placeholder="Book_Name"></div>
						<div class="form-group"><label for="">book Price</label><input type="text" class="form-control" name="bookprice" placeholder="Book_Price"></div>
						<div class="form-group"><input type="submit" class="btn btn-info btn-block" value="Add Books"></div>
					</form>
						<!--  Store_Data_Validation -->
	<script type="text/javascript" src="Lib/bootstrapValidator.min.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$('#Validate').bootstrapValidator({
					feedbackIcons:{
						valid:'glyphicon glyphicon-ok',
						invalid:'glyphicon glyphicon-remove',
						validating:'glyphicon glyphicon-refresh'
					},
					fields:{
						bookname:{
							validators:{
								regexp:{
									regexp:/^[a-z\s]+$/i,
									message:"Please Enter Letters and Space Only"
												},
								stringLength:{
									max:200,
									message:"Please Name Consist of 200 letters Only"
								},
								notEmpty:{
									message:"Please Enter Book_Name"
								}
							}
						},
						bookprice:{
							validators:{
								numeric:{
									message:'Please Enter number only'
								},
								stringLength:{
									max:10,
									message:"Please Enter Maximum 1000000  Only"
								},
								notEmpty:{
									message:'Please Enter Book_Price'
								}
							}
						}
						}
					});
				});
			</script>
		</div>
						<!--  Display_Store_Data -->

				<div class="col-md-6">
					<h2 class="text-center">Display Data</h2>
				<table class="table table-responsive">
					<thead>
						<tr class="text-center">
							<th>Book Title</th>
							<th>Book Price</th>
							<th colspan="2" class="text-center">Action</th>
						</tr>
						<tbody>
	<?php
		include('dbcon.php');
		$stmt=$con->prepare("select * from bookshop");
		$stmt->execute();
		$result=$stmt->setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt->fetchAll() as $key => $value) {
		echo "<tr>
								<td>".$value['Book_Title']."</td>
								<td>".$value['Book_Price']."</td>
								<td>
									<a href='EditForm.php?id=".$value['Book_id']."'><input type='button' class='btn btn-success' value='Edit-Book' name='Edit'></a>
								</td>
								<td>
									<a href='delete.php?id=".$value['Book_id']."'><input type='button' class='btn btn-danger' value='Delete-Book' name='Delete'></a>
								</td>
							</tr>";
		}
		?>
						</tbody>
					</thead>
				</table>
			</div>
			</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>