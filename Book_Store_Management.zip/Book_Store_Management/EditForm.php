<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Store Application</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	#white{
		color:white;
	}
	#white:hover{
		background-color: lightskyblue;
	}
	.container{
		margin-top: 130px;
	}
</style>
</head>
<body>
							<!--  Store_Head -->

	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid bg-primary">
			<h1 class="text-center" >Book Store</h1>
			<div class="navbar-header">
				<button class="navbar-toggle" data-toggle="collapse" data-target="#Bar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div class="navbar-brand" id="white">WELCOME</div>
			</div>
			<div class="collapse navbar-collapse" id="Bar">
				<ul class="nav navbar-nav">
					<li><a href="" id="white">Home</a></li>
					<li><a href="" id="white">Service</a></li>
					<li><a href="" id="white">Login</a></li>
					<li><a href="" id="white">SignUp</a></li>
				</ul>
			</div>
		</div>
	</nav>
						<!--  Fetch-Data -->
	<?php
		include('dbcon.php');
		$id=$_GET['id'];
		$stmt=$con->prepare("select * from bookshop where Book_id=:id");
		$stmt->bindParam(':id',$id);
		$stmt->execute();
		$result=$stmt->setFetchMode(PDO::FETCH_ASSOC);
		foreach ($stmt->fetchAll() as $key => $value) {
			?>
									<!--  Store_Body -->
	<div class="container">
		<div class="panel panel-warning">
			<div class="panel-body bg-primary">
			<div class="row ">
					<h2 class="text-center">Edit Store Data</h2>
					<form action="editdata.php" method="post" id="EditValidate" class="text-center">
						<input type="hidden" name="bookid" value="<?php 
						echo $value['Book_id']?>" >
						<div class="col-md-6">
							<div class="form-group"><label for="" class="text-center">Book Title</label></div>
							<div class="form-group"><label for="" class="text-center">Book Price</label>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group"><input type="text" class="form-control" name="bookname" placeholder="Enter Book_Title" value="<?php 
						echo $value['Book_Title']?>"></div>
							<div class="form-group"><input type="text" class="form-control" name="bookprice" placeholder="Enter Book_Price" value="<?php 
						echo $value['Book_Price']?>">
							</div>
						</div>
						<div class="row form-group">
							<input type="submit" class="btn btn-info col-md-offset-5 col-md-2" value="Edit Books">
						</div>
					<?php }?>
					</form>
						<!--  Store_Data_Validation -->
	<script type="text/javascript" src="Lib/bootstrapValidator.min.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$('#EditValidate').bootstrapValidator({
					feedbackIcons:{
						valid:'glyphicon glyphicon-ok',
						invalid:'glyphicon glyphicon-remove',
						validating:'glyphicon glyphicon-refresh'
					},
					fields:{
						bookname:{
							validators:{
								regexp:{
									regexp:/^[a-z\s]+$/i,
									message:"Please Enter Letters and Space Only"
												},
								stringLength:{
									max:200,
									message:"Please Name Consist of 200 letters Only"
								},
								notEmpty:{
									message:"Please Enter Book_Name"
								}
							}
						},
						bookprice:{
							validators:{
								numeric:{
									message:'Please Enter number only'
								},
								stringLength:{
									max:10,
									message:"Please Enter Maximum 1000000  Only"
								},
								notEmpty:{
									message:'Please Enter Book_Price'
								}
							}
						}
						}
					});
				});
			</script>
			</div>
			</div>
		</div>
	</div>
</body>
</html>